from django.apps import AppConfig


class EventmanagerConfig(AppConfig):
    name = 'EventManager'
