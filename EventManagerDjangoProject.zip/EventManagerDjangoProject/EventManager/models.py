from django.db import models


class Administrador(models.Model):
    utilizador_ptr_id = models.IntegerField(primary_key=True)
    gabinete = models.CharField(max_length=255)

    class Meta:
        managed = False
        db_table = 'administrador'


class Answer(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)  # Field name made lowercase.
    questionsid_questions = models.OneToOneField('Questions', models.DO_NOTHING, db_column='QuestionsID_Questions')  # Field name made lowercase.
    eventid_event = models.OneToOneField('Event', models.DO_NOTHING, db_column='EventID_Event', blank=True, null=True)  # Field name made lowercase.
    resgistrationid = models.ForeignKey('Resgistration', models.DO_NOTHING, db_column='ResgistrationID', blank=True, null=True)  # Field name made lowercase.
    answer = models.CharField(max_length=255)

    class Meta:
        managed = False
        db_table = 'answer'


class Asset(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)  # Field name made lowercase.
    assetname = models.CharField(db_column='AssetName', unique=True, max_length=255)  # Field name made lowercase.
    quantity = models.IntegerField(db_column='Quantity')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'asset'


class AssetEvent(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)  # Field name made lowercase.
    assetid_asset = models.OneToOneField(Asset, models.DO_NOTHING, db_column='AssetID_Asset')  # Field name made lowercase.
    eventid_event = models.OneToOneField('Event', models.DO_NOTHING, db_column='EventID_Event')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'asset_event'


class AssetLogistics(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)  # Field name made lowercase.
    eventid_event = models.ForeignKey('Event', models.DO_NOTHING, db_column='EventID_Event')  # Field name made lowercase.
    servicetypeid_servicetype = models.ForeignKey('Servicetype', models.DO_NOTHING, db_column='ServiceTypeID_ServiceType', blank=True, null=True)  # Field name made lowercase.
    equipmenttypeid_equipmenttype = models.ForeignKey('Equipmenttype', models.DO_NOTHING, db_column='EquipmentTypeID_EquipmentType', blank=True, null=True)  # Field name made lowercase.
    seats = models.IntegerField(db_column='Seats', blank=True, null=True)  # Field name made lowercase.
    seatsforreducedmobility = models.IntegerField(db_column='SeatsForReducedMobility', blank=True, null=True)  # Field name made lowercase.
    quantity = models.IntegerField(db_column='Quantity')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'asset_logistics'


class AuthGroup(models.Model):
    name = models.CharField(unique=True, max_length=150)

    class Meta:
        managed = False
        db_table = 'auth_group'


class AuthGroupPermissions(models.Model):
    group = models.ForeignKey(AuthGroup, models.DO_NOTHING)
    permission = models.ForeignKey('AuthPermission', models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_group_permissions'
        unique_together = (('group', 'permission'),)


class AuthPermission(models.Model):
    name = models.CharField(max_length=255)
    content_type = models.ForeignKey('DjangoContentType', models.DO_NOTHING)
    codename = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'auth_permission'
        unique_together = (('content_type', 'codename'),)


class AuthUser(models.Model):
    password = models.CharField(max_length=128)
    last_login = models.DateTimeField(blank=True, null=True)
    is_superuser = models.IntegerField()
    username = models.CharField(unique=True, max_length=150)
    first_name = models.CharField(max_length=150)
    last_name = models.CharField(max_length=150)
    email = models.CharField(max_length=254)
    is_staff = models.IntegerField()
    is_active = models.IntegerField()
    date_joined = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'auth_user'


class AuthUserGroups(models.Model):
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)
    group = models.ForeignKey(AuthGroup, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_user_groups'
        unique_together = (('user', 'group'),)


class AuthUserUserPermissions(models.Model):
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)
    permission = models.ForeignKey(AuthPermission, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_user_user_permissions'
        unique_together = (('user', 'permission'),)


class Building(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)  # Field name made lowercase.
    campusid = models.ForeignKey('Campus', models.DO_NOTHING, db_column='CampusID')  # Field name made lowercase.
    buildingname = models.CharField(db_column='BuildingName', unique=True, max_length=255)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'building'


class Campus(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)  # Field name made lowercase.
    campusname = models.CharField(db_column='CampusName', unique=True, max_length=255)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'campus'


class Colaborador(models.Model):
    utilizador_ptr_id = models.IntegerField(primary_key=True)
    curso_id = models.IntegerField()
    departamento_id = models.IntegerField()
    faculdade_id = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'colaborador'


class Coordenador(models.Model):
    utilizador_ptr_id = models.IntegerField(primary_key=True)
    gabinete = models.CharField(db_column='Gabinete', max_length=255)  # Field name made lowercase.
    departamentoid = models.IntegerField(db_column='DepartamentoID')  # Field name made lowercase.
    faculdadeid = models.IntegerField(db_column='FaculdadeID')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'coordenador'


class Day(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)  # Field name made lowercase.
    scheduleid_schedule = models.ForeignKey('Schedule', models.DO_NOTHING, db_column='ScheduleID_Schedule')  # Field name made lowercase.
    day = models.DateField(db_column='Day')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'day'


class DjangoAdminLog(models.Model):
    action_time = models.DateTimeField()
    object_id = models.TextField(blank=True, null=True)
    object_repr = models.CharField(max_length=200)
    action_flag = models.PositiveSmallIntegerField()
    change_message = models.TextField()
    content_type = models.ForeignKey('DjangoContentType', models.DO_NOTHING, blank=True, null=True)
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'django_admin_log'


class DjangoContentType(models.Model):
    app_label = models.CharField(max_length=100)
    model = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'django_content_type'
        unique_together = (('app_label', 'model'),)


class DjangoMigrations(models.Model):
    app = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    applied = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_migrations'


class DjangoSession(models.Model):
    session_key = models.CharField(primary_key=True, max_length=40)
    session_data = models.TextField()
    expire_date = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_session'


class Equipment(models.Model):
    assetid = models.OneToOneField(Asset, models.DO_NOTHING, db_column='AssetID', primary_key=True)  # Field name made lowercase.
    equipmenttypeid_equipmenttype = models.ForeignKey('Equipmenttype', models.DO_NOTHING, db_column='EquipmentTypeID_EquipmentType')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'equipment'


class Equipmenttype(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)  # Field name made lowercase.
    typename = models.CharField(db_column='TypeName', unique=True, max_length=255)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'equipmenttype'


class Event(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)  # Field name made lowercase.
    eventtypeid = models.ForeignKey('Eventtype', models.DO_NOTHING, db_column='EventTypeID')  # Field name made lowercase.
    formresgistrationid = models.ForeignKey('Form', models.DO_NOTHING, db_column='FormResgistrationID')  # Field name made lowercase.
    formfeedbackid = models.ForeignKey('Form', models.DO_NOTHING, db_column='FormFeedBackID')  # Field name made lowercase.
    campusid = models.ForeignKey(Campus, models.DO_NOTHING, db_column='CampusID')  # Field name made lowercase.
    wasvalidated = models.TextField(db_column='wasValidated')  # Field name made lowercase. This field type is a guess.
    proponentid = models.ForeignKey('Utilizador', models.DO_NOTHING, db_column='ProponentID')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'event'


class Eventtype(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)  # Field name made lowercase.
    typename = models.CharField(db_column='TypeName', max_length=255)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'eventtype'


class Form(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)  # Field name made lowercase.
    eventtypeid = models.ForeignKey(Eventtype, models.DO_NOTHING, db_column='EventTypeID')  # Field name made lowercase.
    formtypeid_formtype = models.ForeignKey('Formtype', models.DO_NOTHING, db_column='FormTypeID_FormType')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'form'


class Formtype(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)  # Field name made lowercase.
    typename = models.CharField(db_column='TypeName', max_length=255)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'formtype'


class Informacaomensagem(models.Model):
    data = models.DateTimeField()
    pendente = models.IntegerField()
    titulo = models.CharField(max_length=255)
    descricao = models.CharField(max_length=255)
    tipo = models.CharField(max_length=255)
    lido = models.IntegerField()
    emissorid = models.IntegerField(blank=True, null=True)
    recetorid = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'informacaomensagem'


class Informacaonotificacao(models.Model):
    data = models.DateTimeField()
    pendente = models.IntegerField()
    titulo = models.CharField(max_length=255)
    descricao = models.CharField(max_length=255)
    tipo = models.CharField(max_length=255)
    lido = models.IntegerField()
    emissorid = models.IntegerField(blank=True, null=True)
    recetorid = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'informacaonotificacao'


class Mensagemenviada(models.Model):
    mensagem_id = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'mensagemenviada'


class Mensagemrecebida(models.Model):
    mensagem_id = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'mensagemrecebida'


class Multipleoptions(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)  # Field name made lowercase.
    questionsid_questions = models.ForeignKey('Questions', models.DO_NOTHING, db_column='QuestionsID_Questions')  # Field name made lowercase.
    option = models.CharField(db_column='Option', max_length=255)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'multipleoptions'


class Notificacao(models.Model):
    level = models.CharField(max_length=20)
    unread = models.IntegerField()
    actor_object_id = models.CharField(max_length=255)
    verb = models.CharField(max_length=255)
    description = models.TextField(blank=True, null=True)
    target_object_id = models.CharField(max_length=255, blank=True, null=True)
    action_object_object_id = models.CharField(max_length=255, blank=True, null=True)
    timestamp = models.DateTimeField()
    public = models.IntegerField()
    deleted = models.IntegerField()
    emailed = models.IntegerField()
    data = models.TextField(blank=True, null=True)
    titulo = models.CharField(max_length=255)
    descricao = models.CharField(max_length=255)
    tipo = models.CharField(max_length=255)
    action_object_content_type_id = models.IntegerField(blank=True, null=True)
    actor_content_type_id = models.IntegerField()
    recipient_id = models.IntegerField()
    target_content_type_id = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'notificacao'


class Participante(models.Model):
    utilizador_ptr_id = models.IntegerField(primary_key=True)

    class Meta:
        managed = False
        db_table = 'participante'


class Professoruniversitario(models.Model):
    utilizador_ptr_id = models.IntegerField(primary_key=True)
    gabinete = models.CharField(db_column='Gabinete', max_length=255)  # Field name made lowercase.
    departamento_id = models.IntegerField()
    faculdade_id = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'professoruniversitario'


class Questions(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)  # Field name made lowercase.
    questiontypeid_questiontype = models.ForeignKey('Questiontype', models.DO_NOTHING, db_column='QuestionTypeID_QuestionType')  # Field name made lowercase.
    question = models.CharField(max_length=255)

    class Meta:
        managed = False
        db_table = 'questions'


class QuestionsForm(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)  # Field name made lowercase.
    questionsid_questions = models.OneToOneField(Questions, models.DO_NOTHING, db_column='QuestionsID_Questions')  # Field name made lowercase.
    formid_form = models.OneToOneField(Form, models.DO_NOTHING, db_column='FormID_Form')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'questions_form'


class Questiontype(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)  # Field name made lowercase.
    typename = models.IntegerField(db_column='TypeName')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'questiontype'


class Resgistration(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)  # Field name made lowercase.
    eventid_event = models.ForeignKey(Event, models.DO_NOTHING, db_column='EventID_Event')  # Field name made lowercase.
    date = models.IntegerField(db_column='Date', blank=True, null=True)  # Field name made lowercase.
    waspresent = models.IntegerField(db_column='WasPresent', blank=True, null=True)  # Field name made lowercase.
    participantuserid = models.ForeignKey(Participante, models.DO_NOTHING, db_column='ParticipantUserID')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'resgistration'


class Responsavel(models.Model):
    nome = models.CharField(max_length=128)
    email = models.CharField(max_length=128)
    tel = models.CharField(max_length=128)
    inscricao_id = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'responsavel'


class Rooms(models.Model):
    assetid = models.OneToOneField(Asset, models.DO_NOTHING, db_column='AssetID', primary_key=True)  # Field name made lowercase.
    buildingid_building = models.ForeignKey(Building, models.DO_NOTHING, db_column='BuildingID_Building')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'rooms'


class Schedule(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)  # Field name made lowercase.
    eventid = models.ForeignKey(Event, models.DO_NOTHING, db_column='EventID')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'schedule'


class Service(models.Model):
    assetid = models.OneToOneField(Asset, models.DO_NOTHING, db_column='AssetID', primary_key=True)  # Field name made lowercase.
    servicetypeid_servicetype = models.ForeignKey('Servicetype', models.DO_NOTHING, db_column='ServiceTypeID_ServiceType')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'service'


class Servicetype(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)  # Field name made lowercase.
    typename = models.CharField(db_column='TypeName', unique=True, max_length=255)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'servicetype'


class Timebracket(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)  # Field name made lowercase.
    assetid = models.ForeignKey(Asset, models.DO_NOTHING, db_column='AssetID', blank=True, null=True)  # Field name made lowercase.
    asset_logisticsid = models.ForeignKey(AssetLogistics, models.DO_NOTHING, db_column='Asset_logisticsID', blank=True, null=True)  # Field name made lowercase.
    dayid_day = models.ForeignKey(Day, models.DO_NOTHING, db_column='DayID_Day')  # Field name made lowercase.
    starttime = models.TimeField(db_column='StartTime')  # Field name made lowercase.
    endtime = models.TimeField(db_column='EndTime')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'timebracket'


class Utilizador(models.Model):
    user_ptr_id = models.IntegerField(primary_key=True)
    contacto = models.CharField(max_length=20)
    valido = models.CharField(max_length=255)

    class Meta:
        managed = False
        db_table = 'utilizador'